//
//  CustomerUpdateViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 26/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class CustomerUpdateViewController: UIViewController {

    @IBOutlet var Cbu: UITextField!
    @IBOutlet var Cemail: UITextField!
    @IBOutlet var Cid: UITextField!
    @IBOutlet var Cphone: UITextField!
    @IBOutlet var Cname: UITextField!
    
    @IBOutlet var Cproduct: UITextField!
    @IBOutlet var sucessmsg: UILabel!
    
    @IBOutlet var Caddress: UITextField!
    @IBAction func updateCustomer(_ sender: Any) {
        updateCustomerToFirebase()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func updateCustomerToFirebase(){
        let cname = self.Cname.text
        let cphone = self.Cphone.text
        let cid = self.Cid.text
        let cemail = self.Cemail.text
        let cbu = self.Cbu.text
        let cproduct = self.Cproduct.text
        let caddress = self.Caddress.text
        
        if ((cname?.isEmpty)! || (cproduct?.isEmpty)! || (caddress?.isEmpty)! || (cphone?.isEmpty)! || (cbu?.isEmpty)! || (cid?.isEmpty)! || (cemail?.isEmpty)!)
        {
            
            sucessmsg.text = "Error:Please add Customer details"
        }

        
        else{
            let reference1 = Database.database().reference().child("updateCustomers")
            let defaults = UserDefaults.standard
            let userId = defaults.string(forKey: "USERID")
        
        let id1 = reference1.childByAutoId().key
            let favs : [String : AnyObject] = ["cname":cname as AnyObject, "user": userId as AnyObject,"cphone": cphone as AnyObject,"cemail": cemail as AnyObject,"cproduct": cproduct as AnyObject,"cbu": cbu as AnyObject,"caddress": caddress as AnyObject,"cid": cid as AnyObject]
            
        reference1.child(id1).setValue(favs)
        sucessmsg.text = "Sucessfully added Customer details"
        
      }
   }
  
}
