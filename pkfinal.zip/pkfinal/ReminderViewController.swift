//
//  ReminderViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 25/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase


class ReminderViewController:UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var remEnter: UITextField!
    @IBOutlet var remTableView: UITableView!
    var ReminderList : [String] = []
    //var reference1 : DatabaseReference?
    var handler : DatabaseHandle?
    
    @IBAction func addRem(_ sender: Any) {
        let reference1 = Database.database().reference().child("Reminder")
        let defaults = UserDefaults.standard
        let userId = defaults.string(forKey: "USERID")
        let id1 = reference1.childByAutoId().key
        let rem : [String : AnyObject] = ["rem":remEnter.text as AnyObject, "user": userId as AnyObject]
        
        reference1.child(id1).setValue(rem)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ReminderList.count
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = ReminderList[indexPath.row]
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let defaults = UserDefaults.standard
        let userId = defaults.string(forKey: "USERID")
        
        let reference1  = Database.database().reference().child("Reminder")
        handler = reference1.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
            print(DataSnapshot)
            self.ReminderList.removeAll(keepingCapacity: false)
            if let myFavDict = DataSnapshot.value as? [String:AnyObject]{
                for myFav in myFavDict{
                    let myFavorite = myFav.value["rem"] as! String
                    self.ReminderList.append(myFavorite)
                }
                
                self.remTableView.reloadData()
            }
        })
    }
    
    
    // Do any additional setup after loading the view.
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

