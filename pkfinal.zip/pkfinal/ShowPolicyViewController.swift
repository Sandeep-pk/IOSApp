//
//  ShowPolicyViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 27/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class ShowPolicyViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var policyShow: UITableView!
    
    var policyList : [String] = []
    
    var handler : DatabaseHandle?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let defaults = UserDefaults.standard
        let userId = defaults.string(forKey: "USERID")
        
        let reference1  = Database.database().reference().child("policydetails")
        handler = reference1.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
            
            print(DataSnapshot)
            
            
            
            self.policyList.removeAll(keepingCapacity: false)
            if let myFavDict = DataSnapshot.value as? [String:AnyObject]{
                for myFav in myFavDict{
                    let myFavorite = myFav.value["Pname"] as! String
                    let myFavorite1 = myFav.value["Pid"] as! String
                    let myFavorite2 = myFav.value["Pto"] as! String
                    let myFavorite3 = myFav.value["Pfrom"] as! String
                    
                    self.policyList.append("Name:\(myFavorite)")
                    self.policyList.append("Policy Id:\(myFavorite1)")
                    self.policyList.append("To:\(myFavorite2)")
                    self.policyList.append("From:\(myFavorite3)")
                    self.policyList.append("**********")
                    print(myFavorite)
                }
                
                self.policyShow.reloadData()
            }
        })

        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return policyList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = policyList[indexPath.row]
        return cell
    }
}
