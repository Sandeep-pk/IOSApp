//
//  GetPolicyViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 27/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class GetPolicyViewController: UIViewController {
    @IBOutlet var policyName: UITextField!
    @IBOutlet var policyId: UITextField!
    @IBOutlet var policyFrom: UITextField!
    @IBOutlet var policyTo: UITextField!
    
    @IBOutlet var policysucessmsg: UILabel!
    @IBAction func SubmitPolicy(_ sender: Any) {
         getPolicyDetails()
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
func getPolicyDetails()
{
    
    
    
        let Pname = self.policyName.text
        let Pid = self.policyId.text
        let Pfrom = policyFrom.text
        let Pto = self.policyTo.text
    
    if ((Pname?.isEmpty)! || (Pid?.isEmpty)! || (Pto?.isEmpty)! || (Pfrom?.isEmpty)!)
    {
        
        policysucessmsg.text = "Error"
    }
    
       else{
        let reference1 = Database.database().reference().child("policydetails")
        let defaults = UserDefaults.standard
        let userId = defaults.string(forKey: "USERID")
        
        let id1 = reference1.childByAutoId().key
        let favs : [String : AnyObject] = ["Pname":Pname as AnyObject, "user": userId as AnyObject,"Pid": Pid as AnyObject,"Pto": Pto as AnyObject,"Pfrom": Pfrom as AnyObject]
        
        reference1.child(id1).setValue(favs)
    
    
            policysucessmsg.text = "Sucessfully added"
            
        }
    
    
    
    
    
    }
    
}
