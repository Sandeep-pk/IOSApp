//
//  AboutUsViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 17/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit

class AboutUsViewController: UIViewController {

    
    @IBOutlet var AboutPage: UIWebView!
   
    
        override func viewDidLoad() {
        super.viewDidLoad()
            let url = URL(string : "http://www.navitaslifesciences.com/")
            AboutPage.loadRequest(URLRequest(url: url!))
            
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*func LoadAddressUrl()
    {
        let requestUrl = NSURL(string : URLPath)
        let request = NSURLRequest(URL : requestUrl)
        UIWebView.loadRequest(request)
        
    }*/
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
