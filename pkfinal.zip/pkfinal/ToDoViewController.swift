//
//  favViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 22/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase


class ToDoViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var todoEnter: UITextField!
    @IBOutlet var ToDoTableView: UITableView!
    var ToDoList : [String] = []
    //var reference1 : DatabaseReference?
    var handler : DatabaseHandle?
    
    @IBAction func addtodo(_ sender: Any) {
   
   
            let reference1 = Database.database().reference().child("TOdo")
            let defaults = UserDefaults.standard
            let userId = defaults.string(forKey: "USERID")
            let id1 = reference1.childByAutoId().key
            let rem : [String : AnyObject] = ["todo":todoEnter.text as AnyObject, "user": userId as AnyObject]
            
            reference1.child(id1).setValue(rem)
            
        

        

    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
                let defaults = UserDefaults.standard
                let userId = defaults.string(forKey: "USERID")
        
                let reference1  = Database.database().reference().child("TOdo")
                handler = reference1.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
                    print(DataSnapshot)
                    self.ToDoList.removeAll(keepingCapacity: false)
                    if let myFavDict = DataSnapshot.value as? [String:AnyObject]{
                        for myFav in myFavDict{
                            let myFavorite = myFav.value["todo"] as! String
                            self.ToDoList.append(myFavorite)
                            
                        }
                        
                        self.ToDoTableView.reloadData()
                    }
                })
    }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return ToDoList.count
        }
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
            cell.textLabel?.text = ToDoList[indexPath.row]
            return cell
        }
    // Do any additional setup after loading the view.
    
}
