//
//  LocationViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 25/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class LocationViewController: UIViewController {

    @IBOutlet var MapLocation: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let span : MKCoordinateSpan = MKCoordinateSpanMake(0.001, 0.001)
        
        let location = CLLocationCoordinate2DMake(12.9008959, 80.092805)
        let region: MKCoordinateRegion = MKCoordinateRegionMake(location, span)
  
        
        MapLocation.setRegion(region, animated: true)
         let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = "Navitas LLP"
        annotation.subtitle = "New Perungalathur, Chennai"
        MapLocation.addAnnotation(annotation)
        
//        var span = MKCoordinateSpanMake(0.0002,0.0002)
//        var region = MKCoordinateRegion(center: location,span: span)
//        MKMapView().setRegion(region, animated: true)
//        let annotation = MKPointAnnotation()
//        annotation.coordinate = location
//        annotation.title = "Navitas LLP"
//        annotation.subtitle =  "New Perungalathur, Chennai"
//        MKMapView().addAnnotation(annotation)
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
