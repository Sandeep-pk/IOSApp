//
//  GetCustomerViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 26/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class GetCustomerViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource{

    @IBOutlet var customer: UITableView!
    
    var customerList : [String] = []
    
    var handler : DatabaseHandle?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let defaults = UserDefaults.standard
        let userId = defaults.string(forKey: "USERID")
        
        let reference1  = Database.database().reference().child("updateCustomers")
        handler = reference1.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
            
            print(DataSnapshot)

            
            
            self.customerList.removeAll(keepingCapacity: false)
           if let myFavDict = DataSnapshot.value as? [String:AnyObject]{
                for myFav in myFavDict{
                    let myFavorite = myFav.value["cname"] as! String
                    let myFavorite1 = myFav.value["cid"] as! String
                    let myFavorite2 = myFav.value["cemail"] as! String
                    let myFavorite3 = myFav.value["cbu"] as! String
                    let myFavorite4 = myFav.value["cphone"] as! String
                    let myFavorite5 = myFav.value["cproduct"] as! String
                    let myFavorite6 = myFav.value["caddress"] as! String

                    self.customerList.append("Customer Name:\(myFavorite)")
                    self.customerList.append("Customer ID:\(myFavorite1)")
                    self.customerList.append("Customer Email:\(myFavorite2)")
                    self.customerList.append("Customer BU:\(myFavorite3)")
                    self.customerList.append("Customer Phone:\(myFavorite4)")
                    self.customerList.append("Customer Product:\(myFavorite5)")
                    self.customerList.append("Customer Address:\(myFavorite6)")
                    self.customerList.append("**********")
                    print(myFavorite)
                }
            
                self.customer.reloadData()
            }
        })
        
        
        
        
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return customerList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = customerList[indexPath.row]
        return cell
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
