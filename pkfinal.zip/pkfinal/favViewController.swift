//
//  favViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 22/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase


class favViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var favEnter: UITextField!
    @IBOutlet var favTableView: UITableView!
    var myFavList : [String] = []
    //var reference1 : DatabaseReference?
    var handler : DatabaseHandle?
    @IBAction func addFav(_ sender: Any) {
        let reference1 = Database.database().reference().child("Favourites")
        let defaults = UserDefaults.standard
        let userId = defaults.string(forKey: "USERID")
        let id1 = reference1.childByAutoId().key
        let favs : [String : AnyObject] = ["favs":favEnter.text as AnyObject, "user": userId as AnyObject]
        
        reference1.child(id1).setValue(favs)

        //        if favEnter.text != ""
//        { let id1 = reference1?.child("Favourites").childByAutoId().key
//        
//        reference1?.child("Favourites").childByAutoId().setValue(favEnter.text)
//                    favEnter.text = ""
//    }
//        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myFavList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = myFavList[indexPath.row]
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*let query = ref.queryOrdered(byChild: "email").queryEqual(toValue: self.emailTextField.text).queryLimited(toFirst: 1)*/
        
        /*
 if let userDict = DataSnapshot.value as? [String:AnyObject]{
 for user in userDict{
 let password = user.value["password"] as! String
 if(self.passwordTextField.text == password){
 let key = user.key
 let userDefaults = UserDefaults.standard
 userDefaults.setValue(key, forKey: "USERID")
 let vc = self.storyboard?.instantiateViewController(withIdentifier: "Home")
 self.present(vc!, animated: true, completion: nil)
 
 
 }
 else{
 //wrong password
 }
 }
 }
*/
 
        let defaults = UserDefaults.standard
        let userId = defaults.string(forKey: "USERID")
 
        let reference1  = Database.database().reference().child("Favourites")
        handler = reference1.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
            print(DataSnapshot)
            self.myFavList.removeAll(keepingCapacity: false)
            if let myFavDict = DataSnapshot.value as? [String:AnyObject]{
                for myFav in myFavDict{
                    let myFavorite = myFav.value["favs"] as! String
                    self.myFavList.append(myFavorite)
                }
                
                self.favTableView.reloadData()
             }
        })
        
        
        
    }
        // Do any additional setup after loading the view.
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
