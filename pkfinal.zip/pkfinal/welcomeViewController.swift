//
//  welcomeViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 30/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class welcomeViewController: UIViewController {

    @IBOutlet var welcomesu: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let ref = Database.database().reference()
        let defaults = UserDefaults.standard
        let userID = defaults.string(forKey: "USERID")!
        print(userID)
        
        ref.child("Employess").child(userID).observeSingleEvent(of: .value, with: { (DataSnapshot) in
            if let snap = DataSnapshot.value as? [String:Any]
            {
                print(snap)
                var name : String!
                 name = (snap["name"] as! String)
                self.welcomesu.text = name
            }})
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
