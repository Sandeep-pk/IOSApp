//
//  profileViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 23/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class profileViewController: UIViewController {
    @IBOutlet var displayGender: UILabel!
    @IBOutlet var displayPhone: UILabel!
    @IBOutlet var displayEmail: UILabel!

    @IBOutlet var displayBu: UILabel!
    @IBOutlet var displayName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        getEntriesfromFirebase()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getEntriesfromFirebase()
    {
        let ref = Database.database().reference()
        let defaults = UserDefaults.standard
        let userID = defaults.string(forKey: "USERID")!
        print(userID)
        
        ref.child("Employess").child(userID).observeSingleEvent(of: .value, with: { (DataSnapshot) in
            if let snap = DataSnapshot.value as? [String:Any]
            {
                print(snap)
                var name : String!
                var businessunit : String!
                var email : String!
                var gender : String!
                var phone : String!
                
                name = (snap["name"] as! String)
                businessunit = (snap["business"] as! String)
                email = (snap["email"] as! String)
                phone = (snap["phone"] as! String)
                gender = (snap["gender"] as! String)
                
                print(businessunit)
                self.displayBu.text = businessunit
                self.displayName.text = name
                self.displayPhone.text = phone
                self.displayGender.text = gender
                self.displayEmail.text = email
                
                
            }
            
            
        }) { (error) in
            print(error.localizedDescription)
        }
    }
}
