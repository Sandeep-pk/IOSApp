//
//  cabViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 27/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//
import Foundation
import UIKit
import MessageUI


class cabViewController: UIViewController ,MFMailComposeViewControllerDelegate {

    @IBOutlet var cabName: UITextField!
    @IBOutlet var cabID: UITextField!
    
    @IBOutlet var cabDestination: UITextField!
    
    @IBOutlet var cabPick: UITextField!
    
    @IBOutlet var cabTime: UITextField!
    @IBOutlet var cabDate: UITextField!
    
    @IBAction func send(_ sender: Any) {
        //sendMail()
        
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        
        let cabName = self.cabName.text
        let cabID = self.cabID.text
        let cabPick = self.cabPick.text
        let cabDestination = self.cabDestination.text
        let cabDate = self.cabDate.text
        let cabTime = self.cabTime.text
        
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
        
        mailComposerVC.setToRecipients(["ttjh.pk@gmail.com"])
        mailComposerVC.setSubject("Sending you an cab request")
        mailComposerVC.setMessageBody("<p>Name:</p>\(cabName)", isHTML: true)
        mailComposerVC.setMessageBody("<p>ID:</p>\(cabID)", isHTML: true)
        mailComposerVC.setMessageBody("<p>Pick Up:</p>\(cabPick)", isHTML: true)
        mailComposerVC.setMessageBody("<p>Destination:</p>\(cabDestination)", isHTML: true)
        mailComposerVC.setMessageBody("<p>Date:</p>\(cabDate)", isHTML: true)
        mailComposerVC.setMessageBody("<p>Time:</p>\(cabTime)", isHTML: true)
        
        return mailComposerVC
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//    func sendMail()
//    {
    
        
        
        
        
//    let mail = MFMailComposeViewController()
//    mail.mailComposeDelegate = self as! MFMailComposeViewControllerDelegate
//    mail.setToRecipients(["ttjh.pk@gmail.com"])
//    mail.setMessageBody("<p>Name:</p>\(cabName)", isHTML: true)
//    mail.setMessageBody("<p>ID:</p>\(cabID)", isHTML: true)
//        mail.setMessageBody("<p>Pick Up:</p>\(cabPick)", isHTML: true)
//    mail.setMessageBody("<p>Destination:</p>\(cabDestination)", isHTML: true)
//    mail.setMessageBody("<p>Date:</p>\(cabDate)", isHTML: true)
//    mail.setMessageBody("<p>Time:</p>\(cabTime)", isHTML: true)
//    
//    present(mail, animated: true)
//    }
    



    
//    @IBAction func sendEmailButtonTapped(sender: AnyObject) {
//        let mailComposeViewController = configuredMailComposeViewController()
//        if MFMailComposeViewController.canSendMail() {
//            self.present(mailComposeViewController, animated: true, completion: nil)
//        } else {
//            self.showSendMailErrorAlert()
//        }
//    }
    
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
        sendMailErrorAlert.show()
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
    
    
    
    // MARK: MFMailComposeViewControllerDelegate Method

    //    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
//        controller.dismiss(animated: true, completion: nil)
//    }
    
    
    
    

}
