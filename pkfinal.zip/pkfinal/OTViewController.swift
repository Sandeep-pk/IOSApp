//
//  OTViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 25/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//


import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class OTViewController: UIViewController, UITableViewDelegate,UITableViewDataSource  {
    var OTrain : [String] = []
    @IBOutlet var TrainingShow: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Database.database().reference().child("OrganisationTraining").observeSingleEvent(of: .value, with: {(DataSnapshot) in if let eventsFull = (DataSnapshot.value as? [String:Any])
        {
            
            var getTrain : String!
            var getTrain1 : String!
            var getTrain2 : String!
            print(eventsFull)
            getTrain = (eventsFull["OT"] as! String)
            getTrain1 = (eventsFull["OT1"] as! String)
            getTrain2 = (eventsFull["OT2"] as! String)
            print(getTrain)
            self.OTrain.append(getTrain)
            self.OTrain.append(getTrain1)
            self.OTrain.append(getTrain2)
            
            self.TrainingShow.reloadData()
            }
        })
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return OTrain.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = OTrain[indexPath.row]
        return cell
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

