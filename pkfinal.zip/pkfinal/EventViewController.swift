//
//  EventViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 24/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class EventViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet var eventShow: UITableView!
    var Event : [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        Database.database().reference().child("Events").observeSingleEvent(of: .value, with: {(DataSnapshot) in if let eventsFull = (DataSnapshot.value as? [String:Any])
           {
            
            var get : String!
            var get1 : String!
            var get2 : String!
            print(eventsFull)
            get = (eventsFull["event"] as! String)
            get1 = (eventsFull["event1"] as! String)
            get2 = (eventsFull["event2"] as! String)
            self.Event.append(get)
            self.Event.append(get1)
            self.Event.append(get2)
            self.eventShow.reloadData()
            }
        })
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Event.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = Event[indexPath.row]
        return cell
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
