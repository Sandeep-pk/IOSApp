//
//  businessTrainingViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 27/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class businessTrainingViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var BUtrain: UITableView!
    
    var myFavorite0 : String = ""
    var handler : DatabaseHandle?
    var handler1 : DatabaseHandle?
    
    var BUList : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // first retrieve userid
        // with userid find business
        // in train datatable find items that match business value (eg CS)
        // display value
        
        //getbutrain()
        let ref = Database.database().reference()
        let defaults = UserDefaults.standard
        let userID = defaults.string(forKey: "USERID")!
        print(userID)
        
        ref.child("Employess").child(userID).observeSingleEvent(of: .value, with: { (DataSnapshot) in
            if let snap = DataSnapshot.value as? [String:Any]
            {
               var businessunit : String!
              businessunit = (snap["business"] as! String)
                
               if businessunit == "cs"
               {
                let ref1 = Database.database().reference()
                ref1.child("butrain").child("cs").observeSingleEvent(of: .value, with: { (DataSnapshot) in
                    if let snap1 = DataSnapshot.value as? [String:Any]
                    {    print(snap1)
                        let cstrain : String
                        let cstrain1 : String
                        
                        let cstrain2 : String
                        cstrain = (snap1["train"] as? String)!
                        cstrain1 = (snap1["train1"] as? String)!
                        cstrain2 = (snap1["train2"] as? String)!
                        print(cstrain)
                        self.BUList.append("1:\(cstrain)")
                        self.BUList.append("2:\(cstrain1)")
                        self.BUList.append("2:\(cstrain2)")
                         self.BUtrain.reloadData()
                        //self.BUtrain.reloadData()
                    }
                })
                }
                if businessunit == "mech"
                {
                    let ref1 = Database.database().reference()
                    ref1.child("butrain").child("mech").observeSingleEvent(of: .value, with: { (DataSnapshot) in
                        if let snap1 = DataSnapshot.value as? [String:Any]
                        {    print(snap1)
                            let cstrain : String
                            let cstrain1 : String
                            
                            let cstrain2 : String
                            cstrain = (snap1["train"] as? String)!
                            cstrain1 = (snap1["train1"] as? String)!
                            cstrain2 = (snap1["train2"] as? String)!
                            print(cstrain)
                            self.BUList.append("1:\(cstrain)")
                            self.BUList.append("2:\(cstrain1)")
                            self.BUList.append("3:\(cstrain2)")
                            self.BUtrain.reloadData()
                            //self.BUtrain.reloadData()
                        }
                    })
                }
                if businessunit == "ece"
                {
                    let ref1 = Database.database().reference()
                    ref1.child("butrain").child("ece").observeSingleEvent(of: .value, with: { (DataSnapshot) in
                        if let snap1 = DataSnapshot.value as? [String:Any]
                        {    print(snap1)
                            let cstrain : String
                            let cstrain1 : String
                            
                            let cstrain2 : String
                            cstrain = (snap1["train"] as? String)!
                            cstrain1 = (snap1["train1"] as? String)!
                            cstrain2 = (snap1["train2"] as? String)!
                            print(cstrain)
                            self.BUList.append("1:\(cstrain)")
                            self.BUList.append("2:\(cstrain1)")
                            self.BUList.append("2:\(cstrain2)")
                            self.BUtrain.reloadData()
                            //self.BUtrain.reloadData()
                        }
                    })
                }
                
//                self.BUtrain.reloadData()
            }
        })
        
    }
        
//        let defaults = UserDefaults.standard
//        let userId = defaults.string(forKey: "USERID")
//        
//                handler1 = reference2.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
//        
//           if let myFavDict1 = DataSnapshot.value as? [String:AnyObject]
//           {
//            
//            self.myFavorite0 = myFavDict1["business"] as! String }
//        })
//                 if myFavorite0 == "cs"
//                 {
//            
//        //let reference1  = Database.database().reference().child("businessTrainings")
//        
//                  Database.database().reference().child("bucs").observeSingleEvent(of: .value, with: {(DataSnapshot) in
//                  
//                    //self.handler = reference1.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
//            
//            print(DataSnapshot)
//            
//            
//            
//            self.BUList.removeAll(keepingCapacity: false)
//            if let myFavDict = DataSnapshot.value as? [String:AnyObject]{
//                for myFav in myFavDict{
//                    let myFavorite = myFav.value["train"] as! String
//                    let myFavorite1 = myFav.value["train1"] as! String
//                    let myFavorite2 = myFav.value["train2"] as! String
//                    
//                    
//                    self.BUList.append("1:\(myFavorite)")
//                    self.BUList.append("2:\(myFavorite1)")
//                    self.BUList.append("3:\(myFavorite2)")
//                    
//                  
//                }
//                
//                self.BUtrain.reloadData()
//            }
//        })
//                }
//            
//        
//    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return BUList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = BUList[indexPath.row]
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
