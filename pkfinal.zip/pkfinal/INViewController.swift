//
//  LoginViewController.swift
//  FirebaseTutorial
//
//  Created by James Dacombe on 16/11/2016.
//  Copyright © 2016 AppCoda. All rights reserved.
//
import UIKit
import Firebase
import FirebaseAuth

class INViewController: UIViewController{
    
    
    @IBOutlet var labelEmail: UILabel!
    
    //@IBOutlet var textWelcome: UILabel!
    
    @IBOutlet var textGender: UITextField!
    @IBOutlet var textFullName: UITextField!
    
    @IBOutlet var textBusinessUnit: UITextField!
    @IBOutlet var textPhone: UITextField!
    //Outlets
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    @IBAction func IN(_ sender: Any) {
 
    
//    //Login Action
//    @IBAction func loginAction(_ sender: AnyObject) {
        
        if self.emailTextField.text == "" || self.passwordTextField.text == "" {
            
            //Alert to tell the user that there was an error because they didn't fill anything in the textfields because they didn't fill anything in
            
            let alertController = UIAlertController(title: "Error", message: "Please enter an email and password.", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        } else {
            
            let ref = Database.database().reference().child("Employess")
            let query = ref.queryOrdered(byChild: "email").queryEqual(toValue: self.emailTextField.text).queryLimited(toFirst: 1)
            query.observeSingleEvent(of: .value, with: { (DataSnapshot) in
                if let userDict = DataSnapshot.value as? [String:AnyObject]{
                    for user in userDict{
                        let password = user.value["password"] as! String
                        //let welcome = user.value["name"] as! String
                        //self.textWelcome.text = welcome
                        if(self.passwordTextField.text == password){
                            let key = user.key
                            let userDefaults = UserDefaults.standard
                            userDefaults.setValue(key, forKey: "USERID")
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "Home")
                            self.present(vc!, animated: true, completion: nil)
                            
                            
                        }
                        else{
                            //wrong password
                        }
                    }
                }
                
            })
        }
        
        
        //        func db(){
        //            let name = "name"
        //            let phone = "phone"
        //            let gender = "gender"
        //            let email = "email"
        //            let password = "password"
        //            let businessunit = "Business Unit"
        //
        //
        //
        //            let post : [String:AnyObject] = ["name":name as AnyObject,"phone":phone as AnyObject,"gender":gender as AnyObject,"email":emailTextField.text! as
        //                AnyObject,"password":passwordTextField.text! as AnyObject,"Business Unit":businessunit as AnyObject]
        //
        //            let employeeRef = Database.database().reference()
        //            employeeRef.child("Employess").childByAutoId().setValue(post)
        //            
        //            //self.labelEmail.text = self.emailTextField.text
        //            
        //        }
        
    }
}
