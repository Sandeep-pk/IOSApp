//
//  LeaveViewController.swift
//  pkfinal
//
//  Created by JPA Solutions on 26/06/17.
//  Copyright © 2017 JPA Solutions. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class LeaveViewController: UIViewController {
    @IBOutlet var leavesleft: UILabel!

    @IBOutlet var leavestaken: UILabel!
    //@IBOutlet var favEnter: UITextField!
    //@IBOutlet var ToDoTableView: UITableView!
    var LeaveList : [String] = []
    //var reference1 : DatabaseReference?
    var handler : DatabaseHandle?
    
    @IBAction func showLeave(_ sender: Any) {
        let defaults = UserDefaults.standard
        let userId = defaults.string(forKey: "USERID")
        
        let reference1  = Database.database().reference().child("leaves")
        handler = reference1.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
            print(DataSnapshot)
            self.LeaveList.removeAll(keepingCapacity: false)
            if let myFavDict = DataSnapshot.value as? [String:AnyObject]{
                for myFav in myFavDict{
                    let myFavorite  = myFav.value["leavestaken"] as! String
                    let m = integer_t(myFavorite)
                    //Float(myFavorite)
                    print(m)
                    let n = 15 - m!
                    print(n)
                    self.leavestaken.text = myFavorite
                    self.leavesleft.text = String(n)
                    //self.leavesleft.text = (15 - m)
                    //let myFavorite2 = myFav.value["todo2"] as! String
                    //self.ToDoList.append(myFavorite)
                    //self.ToDoList.append(myFavorite1)
                    //self.ToDoList.append(myFavorite2)
                    
                }
                
                
            }
        })
    }
    
    
        //       let reference1 = Database.database().reference().child("ToDo")
        //        let defaults = UserDefaults.standard
        //        let userId = defaults.string(forKey: "USERID")
        //        let id1 = reference1.childByAutoId().key
        //        let favs : [String : AnyObject] = ["todo" : "" as AnyObject, "user": userId as AnyObject]
        //
        //        reference1.child(id1).setValue(favs)
        
    
    
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*let query = ref.queryOrdered(byChild: "email").queryEqual(toValue: self.emailTextField.text).queryLimited(toFirst: 1)*/
        
        /*
         if let userDict = DataSnapshot.value as? [String:AnyObject]{
         for user in userDict{
         let password = user.value["password"] as! String
         if(self.passwordTextField.text == password){
         let key = user.key
         let userDefaults = UserDefaults.standard
         userDefaults.setValue(key, forKey: "USERID")
         let vc = self.storyboard?.instantiateViewController(withIdentifier: "Home")
         self.present(vc!, animated: true, completion: nil)
         
         
         }
         else{
         //wrong password
         }
         }
         }
         */
        
//        let reference1 = Database.database().reference().child("leaves")
//        let defaults = UserDefaults.standard
//        let userId = defaults.string(forKey: "USERID")
//        let id1 = reference1.childByAutoId().key
//        let favs : [String : AnyObject] = ["leavestaken" : "" as AnyObject,"user": userId as AnyObject]
//        reference1.child(id1).setValue(favs)
        
        
        
        //        let defaults = UserDefaults.standard
        //        let userId = defaults.string(forKey: "USERID")
        //
        //        let reference1  = Database.database().reference().child("ToDo")
        //        handler = reference1.queryOrdered(byChild:"user").queryEqual(toValue:userId).observe(.value, with:{ (DataSnapshot) in
        //            print(DataSnapshot)
        //            self.ToDoList.removeAll(keepingCapacity: false)
        //             if let myFavDict = DataSnapshot.value as? [String:AnyObject]{
        //                for myFav in myFavDict{
        //                    let myFavorite = myFav.value["todo"] as! String
        //                    self.ToDoList.append(myFavorite)
        //                }
        //
        //                self.ToDoTableView.reloadData()
        //            }
        //        })
        
        
        
    }
    
    // Do any additional setup after loading the view.
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
